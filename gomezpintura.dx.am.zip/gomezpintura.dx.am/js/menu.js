$(document).ready(main);

function main(){
	$('#menubar').click(function(){
		$('#menu').toggle();
	});
	$('#menubarpie').click(function(){
		$('.menupie').toggle();
	});
}